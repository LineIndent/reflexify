import reflex as rx


class MainState(rx.State):
    """The app state."""

    pass
